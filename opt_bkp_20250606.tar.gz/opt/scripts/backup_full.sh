#!/bin/bash

mostrar_help() {
 echo "Uso: $0 -o ORIGEN -d DESTINO"
 echo "Opciones:"
 echo "-o ORIGEN directorio o archivo a respaldar"
 echo "-d DESTINO directorio donde se guarda el backup"
 echo "-ayuda Muestra esta ayuda"
}


if [[ "$1" == "-help" ]]; then
 mostrar_help
 exit 0
fi

while getopts "o:d:" opcion; do
 case "$opcion" in
 o) origen="$OPTARG" ;;
 d) destino="$OPTARG" ;;
 *) mostrar_help;exit 1 ;;
 esac
done

#verifica que las variables no esten vacias
if [[ -z "$origen" || -z "$destino" ]]; then
	echo "Ingresa el origen y el destino"
	exit 1
fi


#verifica que el archivo/directorio exista
if [[ ! -e "$origen" ]]; then
	echo "Error: el origen '$origen' no existe." >&2
	exit 1
fi


#verifica que el directorio este montado
if  ! mountpoint -q "$destino"; then
	echo "Error: el destino '$destino' no esta montado." >&2
	exit 1
fi


fecha=$(date +%Y%m%d)
nombre_base=$(basename "$origen")
archivo_backup="${destino}/${nombre_base}_bkp_${fecha}.tar.gz"

tar -czf "$archivo_backup" -C "$(dirname "$origen")" "$nombre_base"

if [[ $? -eq 0 ]]; then
	echo "Backup exitoso: $archivo_backup"
	exit 0
else
	echo "Error al crear el backup" >&2
	exit 2
fi
